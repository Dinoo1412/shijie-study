# SQL 索引与执行计划

## 理解

索引减少扫描但增加写入维护成本。先根据查询模式选择索引，再用 EXPLAIN 比较计划；小样本下的结果不能代表生产负载。分页和排序必须有稳定的顺序。

## 动手实践

为任务服务生成测试数据，比较无索引与组合索引的计划，实现游标分页并验证边界。

## 交付成果

查询计划、数据规模与延迟对比。

## 验收

- [ ] 索引匹配实际查询
- [ ] 分页不会因排序不稳定漏项
- [ ] 报告注明规模和实验条件

[参考文档](https://www.postgresql.org/docs/current/using-explain.html)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=25)

## 我的复盘
