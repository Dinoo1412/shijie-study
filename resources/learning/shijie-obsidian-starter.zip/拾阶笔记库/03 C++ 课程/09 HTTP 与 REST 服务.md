# HTTP 与 REST 服务

## 理解

使用成熟库处理 HTTP 协议，把学习重点放在请求校验、路由、业务规则和响应语义上。GET 用于读取，修改操作需要明确的方法和状态码。输入不可信，错误响应保持一致，不向访客返回堆栈。

## 动手实践

使用 Boost.Beast 或熟悉的 C++ HTTP 库构建待办 API，提供创建、列表、更新与删除。定义 JSON 字段、状态码和请求大小上限，准备可重复调用的接口用例。

## 交付成果

内存版待办 REST API。

## 验收

- [ ] 合法请求可完成 CRUD，非法输入被拒绝
- [ ] 找不到资源、参数错误和服务故障有不同状态
- [ ] 接口文档包含字段、例子和错误格式

[参考文档](https://www.boost.org/doc/libs/latest/libs/beast/doc/html/index.html)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=9)

## 我的复盘
