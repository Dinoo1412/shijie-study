# Linux 文件、权限与进程

## 理解

后端程序通常运行在 Linux。理解工作目录、环境变量、文件权限、标准输入输出和进程退出码。系统调用可能失败；检查返回值并记录必要上下文，而不是假设开发机上的路径永远可用。

## 动手实践

在 Linux 或 WSL 中运行前面的程序。使用重定向保存日志，检查文件权限，故意提供不存在的路径，观察退出码。只操作练习目录。

## 交付成果

Linux 运行记录与权限排错清单。

## 验收

- [ ] 能解释 stdout、stderr 与退出码
- [ ] 失败路径可重现且错误信息明确
- [ ] 不依赖个人电脑的绝对路径

[参考文档](https://learn.microsoft.com/zh-cn/windows/wsl/install)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=5)

## 我的复盘
