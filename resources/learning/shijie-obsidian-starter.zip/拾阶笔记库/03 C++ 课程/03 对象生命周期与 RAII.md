# 对象生命周期与 RAII

## 理解

资源应绑定到对象生命周期：构造时获得，析构时释放。优先使用标准容器和 unique_ptr 表达独占所有权；shared_ptr 用在确实需要共享所有权的情形。引用和裸指针可以观察对象，但不能让观察者超出对象的生命周期。

## 动手实践

把文件读取器封装为资源对象，让异常或提前返回也能释放文件。写出值、引用、unique_ptr 的所有权说明，检查悬空引用和重复释放。

## 交付成果

资源安全的文件读取器与所有权图。

## 验收

- [ ] 异常或提前返回时仍释放资源
- [ ] 不返回局部对象的引用或指针
- [ ] 能说明复制、移动与共享所有权的区别

[参考文档](https://learn.microsoft.com/zh-cn/cpp/cpp/object-lifetime-and-resource-management-modern-cpp?view=msvc-170)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=3)

## 我的复盘
