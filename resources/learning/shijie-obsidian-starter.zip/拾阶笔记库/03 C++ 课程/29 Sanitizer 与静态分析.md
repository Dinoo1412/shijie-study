# Sanitizer 与静态分析

## 理解

测试通过不代表没有内存和并发缺陷。AddressSanitizer 检查越界与释放后使用，UndefinedBehaviorSanitizer 检查部分未定义行为，ThreadSanitizer 检查数据竞争；工具需要分别配置和解释结果。

## 动手实践

在测试构建启用相应检查器，为越界、释放后使用和竞态各写一个可复现案例，修复后加入回归用例。

## 交付成果

检查器配置、诊断说明与修复记录。

## 验收

- [ ] 内存错误用例得到报告
- [ ] 修复后检查通过
- [ ] 测试构建与发布构建分开

[参考文档](https://clang.llvm.org/docs/AddressSanitizer.html)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=29)

## 我的复盘
