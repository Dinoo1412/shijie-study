# 编译、调试与 CMake

## 理解

C++ 源码先经过编译，再由链接器组合成程序。头文件负责声明，源文件提供定义。先建立一个可重复构建的小工程，之后每个练习都能独立运行和调试。

## 动手实践

创建 src、include、tests 目录。用 CMake 构建 hello 程序，将求和函数拆成独立文件，故意制造一次编译错误和一次链接错误并解释区别。

## 交付成果

一个可在新目录重新构建的 C++ 工程及构建说明。

## 验收

- [ ] 能从干净的 build 目录构建并运行
- [ ] 能用断点观察变量并定位错误
- [ ] README 记录编译器、C++ 标准和运行步骤

[参考文档](https://cmake.org/cmake/help/latest/guide/tutorial/index.html)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=1)

## 我的复盘
