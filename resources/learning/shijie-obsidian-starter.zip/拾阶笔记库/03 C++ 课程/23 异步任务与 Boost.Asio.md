# 异步任务与 Boost.Asio

## 理解

异步操作完成前，缓冲区和连接对象必须保持有效。回调中的错误码、取消和对象生命周期应一起设计；共享状态可使用 strand 串行处理，避免并发回调竞争。

## 动手实践

使用 Boost.Asio 实现带空闲超时的异步回显服务器，测试超时、主动取消及客户端断连。

## 交付成果

异步服务与生命周期说明。

## 验收

- [ ] 缓冲区生命周期覆盖操作
- [ ] 超时会取消并清理连接
- [ ] 回调错误不会终止整个服务

[参考文档](https://www.boost.org/doc/libs/latest/doc/html/boost_asio.html)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=23)

## 我的复盘
