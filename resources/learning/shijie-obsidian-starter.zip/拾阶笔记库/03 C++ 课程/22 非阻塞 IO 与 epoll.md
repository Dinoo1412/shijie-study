# 非阻塞 I/O 与 epoll

## 理解

非阻塞读写可能只完成一部分，也可能暂时无数据。epoll 只报告就绪事件，业务仍需正确管理连接状态、缓冲区和关闭时机；边缘触发需要读取直到 EAGAIN。

## 动手实践

把 TCP 回显服务改为非阻塞事件循环，处理分段消息、半关闭和慢客户端。先验证水平触发，再尝试边缘触发。

## 交付成果

事件循环代码、连接状态图与异常场景测试。

## 验收

- [ ] 处理部分读写与 EAGAIN
- [ ] 断连后释放描述符
- [ ] 消息边界测试通过

[参考文档](https://man7.org/linux/man-pages/man7/epoll.7.html)

[网站课程](https://shijie-study.jean1412.workers.dev/#cpp-lessons?unit=22)

## 我的复盘
