# linkedlist

> DS · 历史练习源码。部分程序用于演示错误或未定义行为，不代表生产实现。每个含 main 的文件应单独编译，不运行旧的 exe。

## 源码

```cpp
#include<iostream>
#include<stdexcept>

using namespace std;





int main(){
    return 0;
}
```

## 我的复盘

- 这个例子解释什么？
- 输入边界与资源生命周期是什么？
- 我能怎样改进和验证？
