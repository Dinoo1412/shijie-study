# sequentialList_6

> DS · 历史练习源码。部分程序用于演示错误或未定义行为，不代表生产实现。每个含 main 的文件应单独编译，不运行旧的 exe。

## 源码

```cpp
/*
给你一个下标从 0 开始的整数数组 nums ，返回 nums 中满足 i mod 10 == nums[i] 的最小下标 i ；如果不存在这样的下标，返回 -1 。
x mod y 表示 x 除以 y 的 余数 。

示例 1：
输入：nums = [0,1,2]
输出：0
解释：
i=0: 0 mod 10 = 0 == nums[0].
i=1: 1 mod 10 = 1 == nums[1].
i=2: 2 mod 10 = 2 == nums[2].
所有下标都满足 i mod 10 == nums[i] ，所以返回最小下标 0

示例 2：
输入：nums = [1,2,3,4,5,6,7,8,9,0]
输出：-1
解释：不存在满足 i mod 10 == nums[i] 的下标

示例 3：
输入：nums = [2,1,3,5,2]
输出：1
解释：1 是唯一一个满足 i mod 10 == nums[i] 的下标
*/

#include<iostream>
#include<vector>
using namespace std;
class Solution1 {
public:
    int smallestEqual(vector<int>& nums) {
        for(int i=0;i<nums.size();++i){
            if(i % 10 == nums[i]){
                return i;
            }
        }
        return -1;
        
    }
};

/*
给定一个二进制数组 nums ， 计算其中最大连续 1 的个数。
示例 1：
输入：nums = [1,1,0,1,1,1]
输出：3
解释：开头的两位和最后的三位都是连续 1 ，所以最大连续 1 的个数是 3.
*/
class Solution2 {
public:
    int findMaxConsecutiveOnes(vector<int>& nums) {
        int res=0,pre=0;
        for(int i = 0;i<nums.size();++i){
            if(nums[i]==1){
                pre=pre+1;
                if(pre>res){
                    res=pre;
                }
            }
            else{
                pre=0;
            }
        }
        return res;
    }
};
class Solution2_1 {
public:
    int findMaxConsecutiveOnes(vector<int>& nums) {
        int ans = 0, cnt = 0;
        for (int x : nums) {
            if (x) {
                cnt++; 
                ans = max(ans, cnt); 
            } else {
                cnt = 0; 
            }
        }
        return ans;
    }
};

```

## 我的复盘

- 这个例子解释什么？
- 输入边界与资源生命周期是什么？
- 我能怎样改进和验证？
